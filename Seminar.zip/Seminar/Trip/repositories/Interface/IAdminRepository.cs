using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using repositories.Models;

namespace repositories.Interface
{
    public interface IAdminRepository
    {
        bool AddTrip(TripModel model);
        bool UpdateTrip(TripModel model);

        List<TripsModel> GetAllTrips();
        List<TripModel> getAllData();
        TripModel getparticularData(int id);
        bool DeleteTrip(int id);
    }
}