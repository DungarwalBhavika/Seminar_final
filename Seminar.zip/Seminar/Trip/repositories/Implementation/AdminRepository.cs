using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Npgsql;
using repositories.Interface;
using repositories.Models;

namespace repositories.Implementation
{
    public class AdminRepository : IAdminRepository
    {
        private readonly string _con;
        private IHttpContextAccessor httpContextAccessor;
        public AdminRepository(IConfiguration configuration, IHttpContextAccessor httpContext)
        {
            _con = configuration.GetConnectionString("DefaultConnection");
            httpContextAccessor = httpContext;
        }

        #region  add trip data in t_tripadmin
        public bool AddTrip(TripModel model)
        {
            return false;
        }
        #endregion

        #region  delete trip data from t_tripadmin
        public bool DeleteTrip(int id)
        {
            return false;
        }
        #endregion

        #region  take all details from t_tripadmin , join with table t_addtrip to take trip destination name
        public List<TripModel> getAllData()
        {
            List<TripModel> data = new List<TripModel>();

            return data;
        }
        #endregion

        #region take trip destination name  for showing in dropdown (t_addtrip)
        public List<TripsModel> GetAllTrips()
        {
            List<TripsModel> data = new List<TripsModel>();
            return null;
        }
        #endregion

        #region Get particular tour details for update
        public TripModel getparticularData(int id)
        {
            return null;
        }
        #endregion

        #region update data on (t_tripadmin) trip data update
        public bool UpdateTrip(TripModel model)
        {
            return false;
        }
        #endregion
    }
}