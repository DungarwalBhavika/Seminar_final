using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Npgsql;
using repositories.Interface;
using repositories.Models;

namespace repositories.Implementation
{
    public class UserRepository : IUserRepository
    {
        private readonly string _con;
        private IHttpContextAccessor httpContextAccessor;
        public UserRepository(IConfiguration configuration, IHttpContextAccessor httpContext)
        {
            _con = configuration.GetConnectionString("DefaultConnection");
            httpContextAccessor = httpContext;
        }

        #region  book trip 
        public bool AddTrip(BookingModel model, int tripId, int newStock)
        {
            return true;
        }
        #endregion

        #region get all trip details for the user to know which trip his/her selected and see their status
        public List<BookingModel> getAllData()
        {
            List<BookingModel> data = new List<BookingModel>();

            UpdateStatusdata(0, "departed");
            return data;
        }
        #endregion

        #region update status data dynamically as per date change
        private void UpdateStatusdata(int bookId, string status)
        {

        }
        #endregion

        #region get particular trip details for the user to book trip
        public TripModel getparticularData(int id)
        {
            return null;
        }
        #endregion

        #region change status data on canceled when user canceled the reservation 
        public bool UpdateStatus(int id, string status)
        {
            return false;
        }
        #endregion
    }
}