using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using repositories.Interface;

namespace repositories.Implementation
{
    public class EmailStrategyFactory : IEmailStrategyFactory
    {
        private readonly IServiceProvider _serviceProvider;

        public EmailStrategyFactory(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public IEmailStrategy CreateEmailStrategy(string emailType)
        {
            return emailType switch
            {
                "registration" => _serviceProvider.GetService<RegistrationEmailStrategy>(),
                "login" => _serviceProvider.GetService<LoginEmailStrategy>(),
                _ => throw new ArgumentException("Invalid email type"),
            };
        }
    }

}