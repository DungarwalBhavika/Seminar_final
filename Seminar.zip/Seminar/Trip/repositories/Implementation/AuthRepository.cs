using System.Data;
using Microsoft.Extensions.Configuration;
using Npgsql;
using Repositories.Interface;
using Repositories.Models;

namespace Repositories.Implementation
{
    public class AuthRepository : IAuthRepository
    {
        private readonly string _con;

        public AuthRepository(IConfiguration configuration)
        {
            _con = configuration.GetConnectionString("DefaultConnection");
        }

        #region Registration  method
        public bool Register(authmodel auth)
        {
            return false;
        }
        #endregion


        #region Authenticate user credentials 
        public authmodel login(authmodel model)
        {

            return null;
        }
        #endregion
    }
}