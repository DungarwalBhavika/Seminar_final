using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace repositories.Interface
{
    public interface IEmailStrategy
    {
        bool SendEmail(string mailid, string firstName);
    }
}