using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using repositories.Interface;

namespace repositories.Implementation
{
    public class LoginEmailStrategy : IEmailStrategy
    {
        #region  Implementation for sending login email
        public bool SendEmail(string mailid, string firstName)
        {
            return true;
        }
        #endregion
    }
}