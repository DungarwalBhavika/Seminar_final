using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using repositories.Interface;

namespace repositories.Implementation
{
    public class RegistrationEmailStrategy : IEmailStrategy
    {
            #region  Implementation for sending registration email
        public bool SendEmail(string mailid, string firstName)
        {
            return true;
        }
        #endregion
    }
}