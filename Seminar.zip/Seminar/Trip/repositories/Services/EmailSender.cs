using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using repositories.Interface;

namespace repositories.Factory
{
    public class EmailSender
    {
        private readonly IEmailStrategyFactory _emailStrategyFactory;

        public EmailSender(IEmailStrategyFactory emailStrategyFactory)
        {
            _emailStrategyFactory = emailStrategyFactory;
        }

        public bool SendEmail(string emailType, string mailid, string firstName)
        {
            var emailStrategy = _emailStrategyFactory.CreateEmailStrategy(emailType);
            return emailStrategy.SendEmail(mailid, firstName);
        }
    }

}