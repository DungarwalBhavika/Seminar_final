using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using repositories.Implementation;
using repositories.Interface;
using Repositories.Implementation;
using Repositories.Interface;

namespace repositories.Factory
{
    public class RepositoryFactory
    {
        public static IAuthRepository CreateAuthRepository(IConfiguration configuration)
        {
            return new AuthRepository(configuration);
        }

        public static IAdminRepository CreateAdminRepository(IConfiguration configuration, IHttpContextAccessor httpContext)
        {
            return new AdminRepository(configuration, httpContext);
        }

        public static IUserRepository CreateUserRepository(IConfiguration configuration, IHttpContextAccessor httpContext)
        {
            return new UserRepository(configuration, httpContext);
        }
    }
}