﻿namespace repositories;
public class Class1
{

}
