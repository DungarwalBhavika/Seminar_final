using repositories.Factory;
using repositories.Implementation;
using repositories.Interface;
using Repositories.Implementation;
using Repositories.Interface;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddScoped<IAuthRepository>(provider =>
{
    var configuration = provider.GetRequiredService<IConfiguration>();
    return RepositoryFactory.CreateAuthRepository(configuration);
});

builder.Services.AddScoped<IAdminRepository>(provider =>
{
    var configuration = provider.GetRequiredService<IConfiguration>();
    var httpContextAccessor = provider.GetRequiredService<IHttpContextAccessor>();
    return RepositoryFactory.CreateAdminRepository(configuration, httpContextAccessor);
});

builder.Services.AddScoped<IUserRepository>(provider =>
{
    var configuration = provider.GetRequiredService<IConfiguration>();
    var httpContextAccessor = provider.GetRequiredService<IHttpContextAccessor>();
    return RepositoryFactory.CreateUserRepository(configuration, httpContextAccessor);
});

builder.Services.AddScoped<IEmailStrategy, RegistrationEmailStrategy>();
builder.Services.AddScoped<IEmailStrategy, LoginEmailStrategy>();
builder.Services.AddScoped<IEmailStrategyFactory, EmailStrategyFactory>();

builder.Services.AddScoped<EmailSender>();
builder.Services.AddHttpContextAccessor();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(19);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}
app.UseSession();
app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
