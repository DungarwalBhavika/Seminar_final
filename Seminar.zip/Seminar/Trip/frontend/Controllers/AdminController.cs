using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using repositories.Factory;
using repositories.Interface;
using repositories.Models;

namespace frontend.Controllers
{
    public class AdminController : Controller
    {
        private readonly ILogger<AdminController> _logger;

        private readonly IAdminRepository _adminRepository;
        private readonly EmailSender _emailSender;

        public AdminController(IAdminRepository adminRepository, EmailSender emailSender, ILogger<AdminController> logger)
        {
            _adminRepository = adminRepository;
            _emailSender = emailSender;
            _logger = logger;
        }
        #region  here we get session data for display purpose , so in all action we can use this session data because we use ajax(single page )
        public IActionResult Index()
        {
            var userEmail = HttpContext.Session.GetString("userEmail");
            TempData["userEmail"] = userEmail;
            var userId = HttpContext.Session.GetInt32("userId");
            TempData["userId"] = userId;
            return View();
        }
        #endregion

        #region use action for add trip for ajax
        public IActionResult Add(TripModel model)
        {
            _adminRepository.AddTrip(model);

            return Json(new { success = true });
        }
        #endregion

        #region use action for update trip for ajax
        public IActionResult Update(TripModel model)
        {
            _adminRepository.UpdateTrip(model);

            return Json(new { success = true });
        }
        #endregion

        #region use action for get all trip for ajax
        public IActionResult AdGetAllTrip()
        {
            var data = _adminRepository.GetAllTrips();

            return Json(data);
        }
        #endregion

        #region use action for get tour data for ajax
        public IActionResult gettourdata()
        {
            var data = _adminRepository.getAllData();

            return Json(data);
        }
        #endregion

        #region use action for get particular data for ajax
        public IActionResult getParticularData(int id)
        {
            var data = _adminRepository.getparticularData(id);

            return Json(data);
        }
        #endregion

        #region use action for delete trip for ajax
        public IActionResult Delete(int id)
        {
            var data = _adminRepository.DeleteTrip(id);

            return Json(data);
        }
        #endregion



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}