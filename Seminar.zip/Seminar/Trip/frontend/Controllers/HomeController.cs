﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using frontend.Models;
using Repositories.Interface;
using Repositories.Models;
using repositories.Factory;

namespace frontend.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly IAuthRepository _authRepository;
    private readonly EmailSender _emailSender;

    public HomeController(ILogger<HomeController> logger, IAuthRepository authRepository, EmailSender emailSender)
    {
        _logger = logger;
        _authRepository = authRepository;
        _emailSender = emailSender;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    #region Register 
    public IActionResult Register([FromForm] authmodel user)
    {
        if (user == null)
        {
            return BadRequest("Invalid request data.");
        }

        bool registerSuccess = _authRepository.Register(user);
        if (registerSuccess)
        {
            #region  register time email send
            bool emailSent = _emailSender.SendEmail("registration", user.c_email, user.c_name);
            if (emailSent)
            {
                return Ok("Registration successful. Confirmation email has been sent.");
            }
            else
            {
                return StatusCode(500, "Registration successful, but failed to send confirmation email.");
            }
            #endregion
        }
        else
        {
            return StatusCode(500, "Registration failed. Please try again.");
        }
    }
    #endregion

    [HttpPost]
    #region  check credential for login if correct then goes in dashboard and save data in session otherwise stay in same page , also send as per role in dashboard (like if role is admin send on admin dashboard )
    public IActionResult Login(authmodel auth)
    {
        var data = _authRepository.login(auth);

        HttpContext.Session.SetInt32("userId", data.c_userid);
        HttpContext.Session.SetString("userEmail", data.c_email);

        #region  login time email send
        bool emailSent = _emailSender.SendEmail("login", auth.c_email, auth.c_name);

        if (emailSent)
        {
            return Json(new { isAdmin = data.c_role != 0 });
        }
        else
        {
            return Conflict(new { message = "Login successful, but failed to send login confirmation email.!!", status = 500 });
        }
        #endregion
    }
    #endregion
    #region  clear session and send in login page

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Index", "Home");
    }
    #endregion
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}