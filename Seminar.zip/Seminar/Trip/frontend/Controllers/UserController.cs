using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using repositories.Factory;
using repositories.Interface;
using repositories.Models;

namespace frontend.Controllers
{
    public class UserController : Controller
    {
        private readonly ILogger<UserController> _logger;

        private readonly IUserRepository _userRepository;
        private readonly EmailSender _emailSender;

        public UserController(IUserRepository userRepository, EmailSender emailSender, ILogger<UserController> logger)
        {
            _userRepository = userRepository;
            _emailSender = emailSender;
            _logger = logger;
        }

        #region  here we get session data for display purpose , so in all action we can use this session data because we use ajax(single page )
        public IActionResult Index()
        {
            var userEmail = HttpContext.Session.GetString("userEmail");
            TempData["userEmail"] = userEmail;
            var userId = HttpContext.Session.GetInt32("userId");
            TempData["userId"] = userId;
            return View();
        }
        #endregion

        #region show the all trip data
        public IActionResult getbookingdata()
        {
            var data = _userRepository.getAllData();
            return Json(data);
        }
        #endregion

        #region  add the trip 
        public IActionResult Add(BookingModel model)
        {
            int newStock = model.c_currentstock - model.c_qty;
            var Booking = _userRepository.AddTrip(model, model.c_tripid, newStock);
            if (Booking)
            {
                return Json(new { success = true });
            }
            return Json(new { success = false });
        }
        #endregion

        #region cancel booked trip
        [HttpPost]
        public IActionResult CancelBooking(int id)
        {
            bool success = _userRepository.UpdateStatus(id, "Canceled");

            if (success)
            {
                return Ok("Booking canceled successfully.");
            }
            else
            {
                return BadRequest("Failed to cancel booking.");
            }
        }
        #endregion

        #region get particular trip data for booked
        public IActionResult getParticularData(int id)
        {
            var data = _userRepository.getparticularData(id);

            return Json(data);
        }
        #endregion

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}